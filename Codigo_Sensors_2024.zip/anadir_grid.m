% A�adimos una rejilla blanca a la imagen original
% LMSJ
imageFile = 'imagen.png';  % nombre de tu archivo original
img = imread(imageFile);

% dimensiones
[height, width, ~] = size(img);

% N�m l�neas de la rejilla
num_vertical_lines = 14;
num_horizontal_lines = 12;

% Posiciones de las l�neas:
x_positions = linspace(1, width, num_vertical_lines + 1);
y_positions = linspace(1, height, num_horizontal_lines + 1);

img_with_grid = img;

for i = 1:length(x_positions)
    x_pos = round(x_positions(i));
    img_with_grid(:, x_pos, :) = 255;  % L�nea blanca
end
for i = 1:length(y_positions)
    y_pos = round(y_positions(i));
    img_with_grid(y_pos, :, :) = 255;  % L�nea blanca
end

figure;
imshow(img_with_grid);
title('Imagen con rejilla superpuesta');

% Guardamos la imagen con la cuadricula
[pathstr, name, ext] = fileparts(imageFile);
outputFile = fullfile(pathstr, [name '_con_rejilla' ext]);
imwrite(img_with_grid, outputFile);
disp(['Imagen guardada en: ', outputFile]);

