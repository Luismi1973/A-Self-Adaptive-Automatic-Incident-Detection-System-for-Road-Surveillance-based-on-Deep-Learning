% An�lisis de frames de video usando GMM (Gaussian Mixture Model).
% LMSJ


function detecta_peligro_en_carretera()
    % videos de entrada
    videoDir = 'videos/';
    videoFiles = dir(fullfile(videoDir, '*.mp4'));

    % Par�metros del modelo GMM
    numGaussians = 5; % N�mero de gaussianass
    learningRate = 0.005; % Tasa de aprendizaje del GMM
    thresholdDiff = 50; % Umbral para detectar diferencias significativas entre frames

    % Procesado de cada video en el directorio
    for i = 1:length(videoFiles)
        
        videoPath = fullfile(videoDir, videoFiles(i).name);
        videoObj = VideoReader(videoPath);
        gmmModel = initializeGMM(videoObj, numGaussians);
        prevFrame = readFrame(videoObj); % Leer primer frame
        prevGray = rgb2gray(prevFrame); % Convertir a escala de grises

        while hasFrame(videoObj)
            currentFrame = readFrame(videoObj);
            currentGray = rgb2gray(currentFrame);
            % diferencia entre el frame actual y el anterior
            diffFrame = abs(double(currentGray) - double(prevGray));
            if max(diffFrame(:)) > thresholdDiff
                fprintf('Diferencia significativa detectada en el frame\n');
                [foregroundMask, gmmModel] = updateGMM(gmmModel, currentFrame, learningRate);
                figure(1);
                subplot(1, 2, 1);
                imshow(currentFrame);
                title('Frame actual');
                subplot(1, 2, 2);
                imshow(foregroundMask);
                title('M�scara de objetos en movimiento');
                drawnow;
            end

            prevGray = currentGray;
        end
    end
end

