
%% Aplica un filtro de mediana a un frame
function filteredFrame = applyMedianFilter(frame, kernelSize)
    % Aplica filtro de mediana a cada canal de color
    filteredFrame = zeros(size(frame), 'like', frame); 
    for ch = 1:3
        filteredFrame(:,:,ch) = medfilt2(frame(:,:,ch), kernelSize);
    end
end

