%% Actualizaci�n del modelo GMM y extracci�n del fondo
function [foregroundMask, gmmModel] = updateGMM(gmmModel, frame, learningRate)
        frame = double(frame);
        [rows, cols, ~] = size(frame);
    numGaussians = size(gmmModel.mean, 3);
    % M�scara de objetos en movimiento (inicialmente todo es fondo)
    foregroundMask = zeros(rows, cols);

    % Itera sobre cada p�xel
    for r = 1:rows
        for c = 1:cols
            pixel = reshape(frame(r, c, :), [1, 1, 3]); 
            matchedGaussian = false;

            % Verificar gaussianas para este p�xel
            for g = 1:numGaussians
                diff = pixel - gmmModel.mean(r, c, g, :);
                distSquared = sum(diff .^ 2, 3); % Distancia euclidea

                if distSquared < 2.5 * gmmModel.variance(r, c, g)
                    matchedGaussian = true;
                    gmmModel.mean(r, c, g, :) = (1 - learningRate) * gmmModel.mean(r, c, g, :) + learningRate * pixel;
                    gmmModel.variance(r, c, g) = (1 - learningRate) * gmmModel.variance(r, c, g) + ...
                                                 learningRate * distSquared;
                    gmmModel.weights(r, c, g) = (1 - learningRate) * gmmModel.weights(r, c, g) + learningRate;
                else
                    gmmModel.weights(r, c, g) = (1 - learningRate) * gmmModel.weights(r, c, g);
                end
            end

            if ~matchedGaussian
                foregroundMask(r, c) = 1; % Objeto en movimiento
            end

            % Normalizamos los pesos de las gaussianas
            gmmModel.weights(r, c, :) = gmmModel.weights(r, c, :) / sum(gmmModel.weights(r, c, :));
        end
    end

    % Pasamos la m�scara a valores binarios (0 = fondo, 1 = objetos en movimiento)
    foregroundMask = logical(foregroundMask);
end
