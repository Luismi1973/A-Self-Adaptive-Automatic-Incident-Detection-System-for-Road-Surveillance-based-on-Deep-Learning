# Descarga los pesos preentrenados de YOLOv4
wget https://pjreddie.com/media/files/yolov4.weights
