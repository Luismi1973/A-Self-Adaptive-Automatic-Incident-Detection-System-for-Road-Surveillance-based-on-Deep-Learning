%% Inicializaci�n del modelo GMM
function gmmModel = initializeGMM(videoObj, numGaussians)
    % Leer el primer frame para obtener las dimensiones
    firstFrame = readFrame(videoObj);
    [rows, cols, ~] = size(firstFrame);

    % Inicializar el modelo GMM para cada p�xel
    gmmModel.mean = rand(rows, cols, numGaussians, 3) * 255; % Medias iniciales aleatorias
    gmmModel.variance = rand(rows, cols, numGaussians) * 255; % Varianzas iniciales
    gmmModel.weights = ones(rows, cols, numGaussians) / numGaussians; % Pesos iniciales
end
