./darknet detector test data/obj.data cfg/yolov4.cfg backup/yolov4_final.weights data/dog.jpg
