import numpy as np
import matplotlib.pyplot as plt
from sklearn.mixture import GaussianMixture
from sklearn.datasets import make_blobs


# Modelo GMM con 3 componentes gaussianas
gmm = GaussianMixture(n_components=3, covariance_type='full')
gmm.fit(X)
labels = gmm.predict(X)

plt.scatter(X[:, 0], X[:, 1], c=labels, s=40, cmap='viridis')
plt.title("Clustering con GMM")
plt.show()

# Estimaci�n de probabilidad de pertenecer a cada cluster
probabilities = gmm.predict_proba(X)
print("Probabilidades de pertenecer a cada cluster:", probabilities)
threshold = 0.2
anomalies = X[np.max(probabilities, axis=1) < threshold]
plt.scatter(X[:, 0], X[:, 1], c=labels, s=40, cmap='viridis')
plt.scatter(anomalies[:, 0], anomalies[:, 1], color='red', s=50, label="Anomal�as")
plt.title("Detecci�n de anomal�as con GMM")
plt.legend()
plt.show()
