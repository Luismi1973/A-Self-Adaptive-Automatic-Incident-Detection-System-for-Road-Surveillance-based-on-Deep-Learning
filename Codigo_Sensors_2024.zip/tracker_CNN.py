import tensorflow as tf
from tensorflow.keras import layers, models
import numpy as np
import cv2
import os

# Definimos la funci�n de activaci�n
def relu(x):
    return tf.keras.activations.relu(x) + 0.1 * tf.keras.activations.relu(-x)

# CNN para detecci�n
def build_cnn(input_shape=(28, 28, 3), num_classes=13):
    model = models.Sequential()

    # Primera capa convolucional con 32 filtros
    model.add(layers.Conv2D(32, (3, 3), activation=relu, input_shape=input_shape))
    model.add(layers.MaxPooling2D((2, 2)))

    # Segunda capa convolucional con 64 filtros
    model.add(layers.Conv2D(64, (3, 3), activation=relu))
    model.add(layers.MaxPooling2D((2, 2)))

    model.add(layers.Flatten())
    model.add(layers.Dense(128, activation=relu))

    # Capa softmax para la clasificaci�n en 13 clases
    model.add(layers.Dense(num_classes, activation='softmax'))

    return model

# Im�genes y etiquetas
def preprocess_data(images_dir, labels, img_size=(28, 28)):
    images = []
    for img_name in os.listdir(images_dir):
        img_path = os.path.join(images_dir, img_name)
        img = cv2.imread(img_path)
        img = cv2.resize(img, img_size)
        images.append(img)
    images = np.array(images)
    labels = np.array(labels)
    return images, labels

# Entrenamiento
def train_cnn():
    images_dir = 'path_to_images'
    labels = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]  # 13 clases

    images, labels = preprocess_data(images_dir, labels)o
    model = build_cnn(input_shape=(28, 28, 3), num_classes=13)
    model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])
    # Entrenamiento
    model.fit(images, labels, epochs=10, validation_split=0.1)

train_cnn()
