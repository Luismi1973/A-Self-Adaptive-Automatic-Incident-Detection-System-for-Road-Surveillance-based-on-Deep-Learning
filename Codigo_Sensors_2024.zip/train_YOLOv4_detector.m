./darknet detector train data/obj.data cfg/yolov4.cfg yolov4.conv.137 -dont_show -map
