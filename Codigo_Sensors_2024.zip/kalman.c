#include <stdio.h>
#include <math.h>

#define DIM 4  // Dimensi�n del estado: [x, y, vx, vy]
typedef struct {
    float state[DIM];         // Estado (x, y, vx, vy)
    float P[DIM][DIM];        // Matriz de covarianza del estado
    float Q[DIM][DIM];        // Matriz de ruido del proceso
    float R[DIM][DIM];        // Matriz de ruido de la observaci�n
} KalmanFilter;

// Inicializar el filtro de Kalman
void kalman_init(KalmanFilter *kf) {
    // Estado inicial [x, y, vx, vy]
    for (int i = 0; i < DIM; i++) {
        kf->state[i] = 0.0;
    }

    // Inicializaci�n de las matrices P, Q y R
    for (int i = 0; i < DIM; i++) {
        for (int j = 0; j < DIM; j++) {
            kf->P[i][j] = (i == j) ? 1.0 : 0.0;
            kf->Q[i][j] = (i == j) ? 0.1 : 0.0;
            kf->R[i][j] = (i == j) ? 0.5 : 0.0;
        }
    }
}

// Predicci�n
void kalman_predict(KalmanFilter *kf, float dt) {
    // Predicci�n del estado
    kf->state[0] += kf->state[2] * dt;  // x += vx * dt
    kf->state[1] += kf->state[3] * dt;  // y += vy * dt
    for (int i = 0; i < DIM; i++) {
        for (int j = 0; j < DIM; j++) {
            kf->P[i][j] += kf->Q[i][j];
        }
    }
}

// Correcci�n del filtro
void kalman_update(KalmanFilter *kf, float z[DIM]) {
    // Calcular el error de la observaci�n
    float y[DIM];
    for (int i = 0; i < DIM; i++) {
        y[i] = z[i] - kf->state[i];
    }
    for (int i = 0; i < DIM; i++) {
        kf->state[i] += y[i];
    }
    for (int i = 0; i < DIM; i++) {
        for (int j = 0; j < DIM; j++) {
            kf->P[i][j] += kf->R[i][j];
        }
    }
}
