[net]
batch=64
subdivisions=16
width=416
height=416
channels=3
momentum=0.949
decay=0.0005
angle=0
saturation = 1.5
exposure = 1.5
hue=.1
learning_rate=0.001
burn_in=1000
max_batches = 
policy=steps
steps=20000,24000
scales=.1,.1


[convolutional]
filters=54  
size=1
stride=1
pad=1
activation=linear

[yolo]
mask = 6,7,8
anchors = 10,13, 16,30, 33,23, 30,61, 62,45, 59,119, 116,90, 156,198, 373,326
classes=13  
num=9
jitter=.3
ignore_thresh = .7
truth_thresh = 1
random=1


[convolutional]
filters=54 
size=1
stride=1
pad=1
activation=linear

[yolo]
mask = 3,4,5
anchors = 10,13, 16,30, 33,23, 30,61, 62,45, 59,119, 116,90, 156,198, 373,326
classes=13  
num=9
jitter=.3
ignore_thresh = .7
truth_thresh = 1
random=1


[convolutional]
filters=54 
size=1
stride=1
pad=1
activation=linear

[yolo]
mask = 0,1,2
anchors = 10,13, 16,30, 33,23, 30,61, 62,45, 59,119, 116,90, 156,198, 373,326
classes=13  
num=9
jitter=.3
ignore_thresh = .7
truth_thresh = 1
random=1
