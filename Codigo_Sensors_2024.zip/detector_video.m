./darknet detector demo data/obj.data cfg/yolov4.cfg backup/yolov4_final.weights -ext_output data/video.mp4
