% Grabcut 
% LMSJ


% Directorio de videos y salida de las m�scaras
videoDir = 'videos';
outputDir = 'output_masks';

if ~exist(outputDir, 'dir')
    mkdir(outputDir);
end

% lista de videos 
videoFiles = dir(fullfile(videoDir, '*.mp4'));

% Procesa cada video del directorio
for k = 1:length(videoFiles)
    videoFile = fullfile(videoDir, videoFiles(k).name);
    video = VideoReader(videoFile);
    
    frameIdx = 0;
    while hasFrame(video)
        frame = readFrame(video);
        [height, width, ~] = size(frame);
        
        mask = uint8(2 * ones(height, width));
        rect = [50, floor(height * 0.5), width - 100, floor(height * 0.4)];
                mask(rect(2):rect(2) + rect(4), rect(1):rect(1) + rect(3)) = 1;  % Primer plano

        % Aplica aqui el algoritmo GrabCut
        [segmentedMask, ~] = grabcut(frame, mask, rect);
        
        binaryMask = (segmentedMask == 1 | segmentedMask == 3);
        
        maskFile = fullfile(outputDir, sprintf('%s_frame%d_mask.png', videoFiles(k).name, frameIdx));
        imwrite(binaryMask, maskFile);
        
       
        frameIdx = frameIdx + 1;
    end
end
